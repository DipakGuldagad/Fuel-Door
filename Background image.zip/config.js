﻿// Configure your Firebase project here. Do NOT put private keys in the browser.
// Get your Firebase config from the Firebase Console (Project settings) and paste below.

window.FIREBASE_CONFIG = {
apiKey: "AIzaSyBvOkBw7cEeDdEfGhHiJkLmNoPqRsTuVwX",
authDomain: "fuel-at-door-demo.firebaseapp.com",
projectId: "fuel-at-door-demo",
storageBucket: "fuel-at-door-demo.appspot.com",
messagingSenderId: "123456789012",
appId: "1:123456789012:web:abcdef1234567890abcdef"
};

// Firestore collection used to store login/registration records
window.FIREBASE_COLLECTION = 'logins';
